#!/bin/bash
python3 bot.py
