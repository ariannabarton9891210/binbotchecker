import os
import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# Load environment variables
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
BINX_USER_ID = os.getenv("BINX_USER_ID")
TURNSTILE_API = os.getenv("TURNSTILE_API", "http://localhost:3000/bypass?site=https://binx.cc/")

BINX_LOGIN_URL = "https://api.binx.cc/api/auth/login"
BINX_CHECK_URL = "https://api.binx.cc/api/proxy/check"

auth_token_cache = {"token": None}

async def get_auth_token():
    if auth_token_cache["token"]:
        return auth_token_cache["token"]
    response = requests.post(BINX_LOGIN_URL, json={"userId": BINX_USER_ID})
    if response.status_code == 200:
        token = response.json().get("token")
        auth_token_cache["token"] = token
        return token
    return None

async def get_turnstile_token():
    try:
        response = requests.get(TURNSTILE_API)
        return response.json().get("cf-turnstile-response")
    except:
        return None

async def ip_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("⚠️ Vui lòng nhập IP

Ví dụ: /ip 75.60.120.201")
        return

    ip = context.args[0]
    token = await get_auth_token()
    turnstile = await get_turnstile_token()

    if not token or not turnstile:
        await update.message.reply_text("❌ Không thể lấy token xác thực hoặc turnstile.")
        return

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "accept": "application/json"
    }
    payload = {
        "ip": ip,
        "turnstile_token": turnstile
    }

    try:
        res = requests.post(BINX_CHECK_URL, headers=headers, json=payload)
        if res.status_code == 200:
            data = res.json()
            ip_info = data.get("ipApiInfo", {})
            country = ip_info.get("country", "N/A")
            region = ip_info.get("regionName", "N/A")
            city = ip_info.get("city", "N/A")
            isp = ip_info.get("isp", "N/A")
            asn = ip_info.get("as", "N/A")
            reply = (
                f"🌐 IP Lookup: `{ip}`
"
                f"📍 Country: {country}
"
                f"🏙️ Region: {region} | City: {city}
"
                f"📡 ISP: {isp}
"
                f"🔢 ASN: {asn}"
            )
            await update.message.reply_text(reply, parse_mode="Markdown")
        else:
            await update.message.reply_text("❌ Lỗi từ phía binx.cc")
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {str(e)}")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🤖 Welcome!
Gõ lệnh `/ip <ip>` để tra cứu IP")

def main():
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("ip", ip_command))
    print("Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
